package io.github.iliasiosifidis.articlestore.consumer;

import io.github.iliasiosifidis.articlestore.ArticleMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class ArticleListener {

  private static final Logger log = LoggerFactory.getLogger(ArticleListener.class);

  @RabbitListener(queues = RabbitConfig.QUEUE)
  void onArticle(ArticleMessage article) {
    log.info("Received {}:{} - {}", article.source(), article.externalId(), article.title());
  }
}
